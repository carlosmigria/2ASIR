#!/bin/bash
opcion=0

while [ $opcion -ne 4 ]
do
clear
    echo "1. crear archivo comprimido con la fecha"
    echo "2. Solicitar archivo para hacerlo ejecutable"
    echo "3. Redireccion de un archivo log a un .txt,sdolita el nombre por pantalla"
    echo "4. Salir"
    read -p "Selecciona una opcion: " opcion

    case $opcion in
        1)
            echo "Creando archivo comprimido con la fecha..."
            fecha=$(date +%Y-%m-%d)
            archivo_comprimido="archivo_$fecha.tar.gz"
            echo "Creando archivo: $archivo_comprimido"
            tar -czf $archivo_comprimido * 2>/dev/null
            echo "Archivo comprimido correctamente."
            read -p "Pulsa una tecla para continuar..."
        ;;
      2)
        echo "introduce nombre del fichero"
        read nombre
      ;;
    esac
done
