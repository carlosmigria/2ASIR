<?php
	$id = $_GET['id'];
	$usr = getUserById($id);
?>
<form action="managers/userManager.php" method="post">
	<input type="hidden" name="op" value="upd">
	<input type="email" name="mail" value="<?php echo $usr['user'];?>" readonly >
	<input type="text" name="name" maxlength="50" value="<?php echo $usr['name'];?>" required>
	<input type="submit" value="Actualizar">
</form>
