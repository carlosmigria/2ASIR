<form action="start.php" method="post">
	<input type="hidden" name="op" value="cal">
	<input type="number" name="capital" placeholder="Importe préstamo" required>
	<input type="number" name="interes" placeholder="Interés anual" required>
	<input type="number" name="plazo" placeholder="Años del préstamo" required>
	<select name="periodicidad">
		<option value="1">Anual</option>
		<option value="2">Semestral</option>
		<option value="4">Trimestral</option>
		<option value="6">Bimensual</option>
		<option value="12" selected="selected">Mensual</option>
	</select>
	<br>
	<input type="submit" value="Enviar">

</form>
<form action="start.php" method="post">
	<input type="hidden" name="op" value="new">
	<input type="hidden" name="user" value="<?php echo $user['user'] ?>" >
	<input type="hidden" name="capital" placeholder="Importe préstamo" value="<?php echo $capital['capital'] ?>" required>
	<input type="hidden" name="interes" placeholder="Interés anual" value="<?php echo $interes['interes']; ?>">
	<input type="hidden" name="plazo" placeholder="Años del préstamo" required>
	<input type= "hidden" name="periodicidad">
	<br>
	<input type="submit" value="guardar">

</form>
<table class="loanTable">
	<thead>
		<tr><th>Cuota</th><th>Interés</th><th>Amortización</th><th>Pendiente</th></tr>
	</thead>
	<tbody>
<?php
	$pr = $_REQUEST['periodicidad'];
	$c = $_REQUEST['capital'];
	$i = $_REQUEST['interes']/(100*$pr);
	$n = $_REQUEST['plazo']*$pr;
	$cuota = ($c*$i)/(1-pow(1+$i,-$n));

	$p = $c;	// pendiente igual a capital inicial
	$tc = $n+1;	// total cuotas igual al numero de cuotas + 1 (para el bucle)
	$ic = 0;	// interes cuota
	$ac = 0;	// amortizacion cuota
	echo '<p class="loanTable"><b>Cuota</b>: '.number_format($cuota, 2,',','.')."</p>";
	for($x=1;$x<$tc;$x++) {
		$ic = $i*$p;
		$ac = $cuota - $ic;
		$p = $p - $ac;
		echo "<tr><td>$x</td><td>".number_format($ic,2,',','.').
		"</td><td>".number_format($ac,2,',','.').
		"</td><td>".number_format($p,2,',','.').
		"</td></tr>";
	}
?>
	</tbody>
</table>