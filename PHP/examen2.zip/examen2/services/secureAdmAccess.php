<?php
require_once('secureAccess.php');
require_once('secureAdm.php');
?>