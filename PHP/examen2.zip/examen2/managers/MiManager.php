<?php
require('../services/secureAccess.php');
require_once('../dao/common.php');

$op = $_REQUEST['op'];
switch ($op) {
    case 'del':
        $link = getLink();
        $user = $_GET['id'];
        $query = "DELETE FROM users WHERE users.user='$user'";
        try {
           mysqli_query($link, $query);
        } catch (Exception $e) {

        } finally {
            $numRows = mysqli_affected_rows($link);
            mysqli_close($link);
            $url = 'admin.php';
            $msg = ($numRows==1)? 'Usuario eliminado correctamente':$e->getMessage();            
        }
        sessionClose();
        $url = 'index.php';
        $msg = 'Usuario dado de baja';
        break;
    default:
        sessionClose();
        $url = 'index.php';
        $msg = 'Sesión cerrada con éxito';
}
goToURL($url,$msg);

?>