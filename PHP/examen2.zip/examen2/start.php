<?php
	require_once('services/secureView.php');
	$user = getUser();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<style type="text/css">
	.loanTable {
		font-family: Arial, Helvetica, sans-serif;
		border-collapse: collapse;
		width: 502px;
	}

	.loanTable td, .loanTable th {
		width: 125px;
		border: 1px solid #ddd;
		padding: 8px;
		text-align: center;
	}

	.loanTable tr:nth-child(even){background-color: #f2f2f2;}

	.loanTable tr:hover {background-color: #ddd;}

	.loanTable th {
		padding-top: 12px;
		padding-bottom: 12px;
		// text-align: left;
		background-color: #369;
		color: white;
	}

	input[type=number], select {
		width: 120px;
		padding: 12px 20px;
		margin: 8px 1px;
		display: inline-block;
		border: 1px solid #ccc;
		border-radius: 4px;
		box-sizing: border-box;
	}

	input[type=submit] {
		width: 502px	;
		background-color: #369;
		color: white;
		padding: 14px 20px;
		margin: 8px 0;
		border: none;
		border-radius: 4px;
		cursor: pointer;
	}

	input[type=submit]:hover {
		background-color: #147;
	}

	div {
		border-radius: 5px;
		background-color: #f2f2f2;
		padding: 20px;
	}
	</style>
</head>
<body>
<a href="managers/loginManager.php">Cerrar sesión</a><br>
<a href="managers/MiManager.php?op=del&id=<?php echo $user['user']; ?>">Dar de baja</a><br>
<br>
<?php
	include('view/loan.php');
	include('view/messages.php');
	getMessage();
?>	
</body>
</html>